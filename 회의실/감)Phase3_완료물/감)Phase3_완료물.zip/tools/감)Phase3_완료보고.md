# 감) Phase 3 완료 보고 — 인물 페이지 · 엑셀형 의견 시트 · KO/EN

작성: 오호(클로드) 2026-09-30 · 근거: WTL-PROP-20260929-01, 아주 공개 승인(2026-09-30)

## 1. 완료물 (GitHub 경로 그대로)

| 경로 | 내용 |
| --- | --- |
| `index.html` | 기존 표 유지 + KO/EN 전환, 이름 클릭→위키(KO 폴백 + EN 배지 + 안내), `상세 ›` 링크, 행별 최신 의견 1줄 + 개수, 하단 사이트 전체 의견(slug=ALL) |
| `leader.html` | `?slug=` 인물 페이지: 순위 배지, 4대 지표 바, 프로필, 위키 버튼, 사진 없으면 영문 이니셜 SVG, 하단 의견 시트 |
| `assets/wtl-common.js` | 공통: 다국어, leaders.csv 파서, 이니셜 SVG, 엑셀형 의견 시트(1줄 말줄임→아코디언, 좋아요, 대댓글, 정렬 3종) |
| `tools/감)의견_스키마_Phase3.sql` | Supabase 적용 SQL 사본 (이미 적용됨) |
| `tools/감)의견_시트백업.gs` | Drive `WTL_고객의견_관리시트` 백업용 Apps Script (1시간마다) |

## 2. 규칙 반영

- 순위·점수: `data/leaders.csv`·표에서만 읽음. 고객은 의견만 쓸 수 있고 DB도 수정·삭제 권한 없음.
- 본문 10~1,000자, 닉네임 20자, 로그인 없음, 1분 1회 (화면 + DB 이중 검사).
- 좋아요: 같은 접속자는 의견당 1회 (DB). 대댓글: `parent_comment_id`, 같은 slug만.
- 허브 분리: 공개 페이지에는 허브·회의실 링크 없음.

## 3. 테스트

- DB: anon 역할로 등록/1분 제한/닉네임 21자 거부/9자 거부/좋아요 중복 무시/ip_hash 조회 거부/수정 거부/대댓글 — 모두 통과 (롤백으로 흔적 없음).
- 화면: 헤드리스 브라우저로 KO/EN 전환, 50행 이름→slug 매칭 50/50, 의견 등록·정렬·아코디언·좋아요, 인물 페이지, 없는 slug, 모바일 390px 가로 넘침 없음.
- 실서버 주의: 1분 제한·좋아요 1회는 Supabase가 넘겨주는 접속 IP(x-forwarded-for)를 씁니다. 배포 뒤 실제로 두 번 연속 등록해 보고 두 번째가 막히는지, 다른 사람 좋아요가 되는지 확인 부탁.

## 4. 그록에게 (배포)

- 위 5개 파일을 main에 커밋 → Netlify 배포.
- 매일 `index.html` 표를 새로 만들 때 `WTL:KEEP` 표시가 있는 줄(스타일 블록, 상단 언어 버튼, `table-wrap`, `all-comments`, 맨 아래 스크립트 2개)을 유지해 주세요. 표 `<thead>`의 `data-i18n`과 마지막 `의견` 칸도 유지.
- 표의 이름(영문)이 `leaders.csv`의 `name_en`과 같아야 행이 연결됩니다.
- 사진: `assets/leaders/{slug}.jpg`가 생기면 자동 표시, 없으면 이니셜.

## 5. 제미니에게 (locales)

`assets/wtl-common.js`의 `EXTRA`에 locales.json에 없는 키 기본값을 두었습니다(예: `link_detail`, `comments_all_title`, `err_rate`, `m_research`, `p_birth` …). locales.json에 같은 키를 넣으면 그 값이 우선합니다.

## 6. 아주 할 일

1. Drive `WTL_고객의견_관리시트` → 확장 프로그램 → Apps Script → `감)의견_시트백업.gs` 붙여넣기 → `installHourlyBackup` 1회 실행.
2. 배포 뒤 사이트에서 의견 1건 써 보기.
