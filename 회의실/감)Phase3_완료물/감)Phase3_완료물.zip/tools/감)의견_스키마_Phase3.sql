-- WTL 고객의견 DB · Phase 3 (작성: 오호(클로드) 2026-09-30)
-- Supabase 프로젝트 hwdzjmeklzkszfqxbvsz 에 적용 완료 (migration: wtl_comments_phase3). 기록용 사본.
-- 요약:
--  * 본문 10~1000자, 닉네임 20자 (CHECK + RLS)
--  * slug = 'ALL'(사이트 전체) 또는 지도자 slug (기존 'site' → 'ALL')
--  * 1분 1회: IP 해시(ip_hash, md5) 기준 트리거. 오류 메시지 RATE_LIMIT
--  * 고객이 넣을 수 있는 컬럼은 slug, parent_comment_id, author, lang, body 뿐 (likes/status/created_at은 서버가 강제)
--  * ip_hash 는 조회 권한 없음 (비공개)
--  * 좋아요: rpc wtl_comment_like(p_id) — 같은 IP 해시는 의견당 1회 (wtl_comment_likes)
--  * 수정·삭제는 고객 불가. 숨김 처리는 관리자(SQL/대시보드)가 status='숨김'
-- 시트 8컬럼 대응: comment_id=id, timestamp=created_at, leader_slug=slug, author, language=lang,
--                content=body, likes, parent_id=parent_comment_id

alter table public.wtl_comments drop constraint if exists wtl_comments_body_check;
alter table public.wtl_comments add constraint wtl_comments_body_check check (char_length(body) between 10 and 1000);
update public.wtl_comments set slug = 'ALL' where slug = 'site';
alter table public.wtl_comments alter column slug set default 'ALL';
alter table public.wtl_comments drop constraint if exists wtl_comments_slug_check;
alter table public.wtl_comments add constraint wtl_comments_slug_check check (slug ~ '^(ALL|[a-z0-9-]{1,80})$');
alter table public.wtl_comments add column if not exists ip_hash text;
create index if not exists wtl_comments_slug_time_idx on public.wtl_comments (slug, created_at desc);
create index if not exists wtl_comments_ip_time_idx on public.wtl_comments (ip_hash, created_at desc);

create or replace function public.wtl_client_hash() returns text
language sql stable set search_path = public as $$
  select md5(trim(split_part(coalesce(
    nullif(current_setting('request.headers', true), '')::json->>'x-forwarded-for',
    nullif(current_setting('request.headers', true), '')::json->>'cf-connecting-ip',
    'unknown'), ',', 1)) || ':wtl-2026');
$$;

create or replace function public.wtl_comments_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare h text; p record;
begin
  h := public.wtl_client_hash();
  if exists (select 1 from public.wtl_comments where ip_hash = h and created_at > now() - interval '60 seconds') then
    raise exception 'RATE_LIMIT' using errcode = 'P0001', hint = '1분에 1회만 등록할 수 있습니다.';
  end if;
  new.id := gen_random_uuid(); new.ip_hash := h; new.likes := 0; new.status := '공개'; new.created_at := now();
  new.author := coalesce(nullif(trim(new.author), ''), 'Anonymous');
  new.body := trim(new.body);
  if new.lang is null or new.lang not in ('ko','en') then new.lang := 'ko'; end if;
  if new.parent_comment_id is not null then
    select slug into p from public.wtl_comments where id = new.parent_comment_id;
    if not found or p.slug <> new.slug then raise exception 'BAD_PARENT' using errcode = 'P0001'; end if;
  end if;
  return new;
end $$;
drop trigger if exists wtl_comments_before_insert on public.wtl_comments;
create trigger wtl_comments_before_insert before insert on public.wtl_comments
  for each row execute function public.wtl_comments_before_insert();

revoke all on public.wtl_comments from anon, authenticated;
grant select (id, slug, parent_comment_id, author, lang, body, likes, status, created_at) on public.wtl_comments to anon, authenticated;
grant insert (slug, parent_comment_id, author, lang, body) on public.wtl_comments to anon, authenticated;
drop policy if exists wtl_comments_insert on public.wtl_comments;
create policy wtl_comments_insert on public.wtl_comments for insert to anon, authenticated
  with check (char_length(body) between 10 and 1000 and char_length(author) <= 20);

create table if not exists public.wtl_comment_likes (
  comment_id uuid not null references public.wtl_comments(id) on delete cascade,
  ip_hash text not null, created_at timestamptz not null default now(),
  primary key (comment_id, ip_hash));
alter table public.wtl_comment_likes enable row level security;
revoke all on public.wtl_comment_likes from anon, authenticated;

drop function if exists public.wtl_comment_like(uuid);
create function public.wtl_comment_like(p_id uuid) returns integer
language plpgsql security definer set search_path = public as $$
declare n integer; h text;
begin
  h := public.wtl_client_hash();
  if not exists (select 1 from public.wtl_comments where id = p_id and status in ('공개','승인')) then
    raise exception 'NOT_FOUND' using errcode = 'P0001';
  end if;
  insert into public.wtl_comment_likes (comment_id, ip_hash) values (p_id, h) on conflict do nothing;
  if found then update public.wtl_comments set likes = likes + 1 where id = p_id returning likes into n;
  else select likes into n from public.wtl_comments where id = p_id; end if;
  return n;
end $$;
revoke all on function public.wtl_comment_like(uuid) from public;
grant execute on function public.wtl_comment_like(uuid) to anon, authenticated;
