/**
 * WTL 고객의견 → Google 시트 백업 (Supabase 주저장 · 시트는 백업)
 * 작성: 오호(클로드) 2026-09-30 · Phase 3
 *
 * 설치 (아주, 약 3분):
 *  1. Drive의 `WTL_고객의견_관리시트`를 연다.
 *  2. 메뉴 [확장 프로그램] → [Apps Script] → 이 파일 내용을 전부 붙여넣고 저장.
 *  3. 함수 목록에서 `installHourlyBackup` 선택 → [실행] → 권한 허용 (1회).
 *     이후 1시간마다 자동 백업. 바로 해 보려면 `backupComments` 실행.
 *
 * 동작:
 *  - `Supabase_백업` 탭을 매번 새로 채운다 (기존 샘플 탭은 건드리지 않음).
 *  - 컬럼은 제미니 확정 8컬럼(data/comments-schema.md) 순서.
 *  - 공개 키(publishable)로 공개된 의견만 읽는다. 쓰기 권한 없음, 비밀키 불필요.
 */
var SUPABASE_URL = "https://hwdzjmeklzkszfqxbvsz.supabase.co";
var SUPABASE_KEY = "sb_publishable_2JorYW_R1etapUtiZMI8Yg_gQTRO-f5";
var TAB = "Supabase_백업";
var HEADERS = ["의견ID", "작성시각", "지도자 slug", "작성자", "작성언어", "의견본문", "좋아요수", "부모댓글ID"];

function backupComments() {
  var rows = [], from = 0, page = 1000;
  while (true) {
    var url = SUPABASE_URL + "/rest/v1/wtl_comments" +
      "?select=id,created_at,slug,author,lang,body,likes,parent_comment_id&order=created_at.asc";
    var res = UrlFetchApp.fetch(url, {
      headers: { apikey: SUPABASE_KEY, Range: from + "-" + (from + page - 1) },
      muteHttpExceptions: true
    });
    if (res.getResponseCode() >= 300) throw new Error("Supabase " + res.getResponseCode() + ": " + res.getContentText());
    var data = JSON.parse(res.getContentText());
    data.forEach(function (c) {
      rows.push([c.id, c.created_at, c.slug, c.author, c.lang, c.body, c.likes, c.parent_comment_id || ""]);
    });
    if (data.length < page) break;
    from += page;
  }
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(TAB) || ss.insertSheet(TAB);
  sh.clearContents();
  sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight("bold");
  if (rows.length) sh.getRange(2, 1, rows.length, HEADERS.length).setValues(rows);
  sh.setFrozenRows(1);
  sh.getRange(1, HEADERS.length + 2).setValue("마지막 백업: " + new Date().toLocaleString("ko-KR") + " · " + rows.length + "건");
}

function installHourlyBackup() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === "backupComments") ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger("backupComments").timeBased().everyHours(1).create();
  backupComments();
}
